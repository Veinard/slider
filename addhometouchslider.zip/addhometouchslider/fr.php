<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{addhometouchslider}prestashop>addhometouchslider_6b00213ec08f6b79a791169b9448ee94'] = 'Ajouter Curseur Touchez sur la page d\'accueil';
